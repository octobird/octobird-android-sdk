package com.octobird.advertising.samples;

import java.sql.Date;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;

import com.octobird.advertising.AdControl;
import com.octobird.advertising.AdLog;

public class SimpleBanner extends Activity {
	private LinearLayout linearLayout;
	AdControl adserverView;
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        ((Button) findViewById(R.id.btnTestOn)).setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		adserverView.Test(true);
        	}
        });
        ((Button) findViewById(R.id.btnTestOff)).setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		adserverView.Test(false);
        	}
        });
        ((Button) findViewById(R.id.btnRefresh)).setOnClickListener(new OnClickListener() {
        	@Override
			public void onClick(View v) {
        		adserverView.Refresh();
        	}
        });
        
        linearLayout = (LinearLayout) findViewById(R.id.frameAdContent);
        
        AdLog.setDefaultLogLevel(AdLog.LOG_LEVEL_ALL);
        
        adserverView = new AdControl(this,"1234");
        
        adserverView.setLayoutParams(new ViewGroup.LayoutParams(300,50));
        adserverView.GPS(45.54544,21.54645);
        adserverView.MaxWidth(320);
        adserverView.MaxHeight(50);
        adserverView.Test(true);
        adserverView.Gender(AdControl.Gender.Male);
        adserverView.Age(66);
        adserverView.Birthday(Date.valueOf("1980-01-03"));
        Date date = adserverView.Birthday();
        adserverView.City("������");
        adserverView.Keywords("�������,����,android");
        linearLayout.addView(adserverView);
    }
}